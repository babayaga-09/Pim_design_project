
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBasic, HTTPBasicCredentials

security = HTTPBasic()

# SUPER simple "session":
# user is logged in if they present Basic auth with correct credentials on every request.
VALID_USER = "admin"
VALID_PASS = "password"

def require_user(credentials: HTTPBasicCredentials = Depends(security)) -> str:
    if credentials.username == VALID_USER and credentials.password == VALID_PASS:
        return credentials.username
    raise HTTPException(status_code=401, detail="Invalid credentials")
